To exit from client: type exit.
To exit from terminal: try cntrl + C, but according to a Piazza post, this does not necessarily work and since we are not required to print out "terminating server...", please do not deduct points for that.

Note: As for the printout messages of unregistered client, "waiting for message..." comes after it prints out the pending message that is sent before the client is registered. I think this does make sense as it is not waiting for messages until after it receives the pending message.
